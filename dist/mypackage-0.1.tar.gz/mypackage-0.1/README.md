#mypackage
This is an example on how to make a package using python

##Building the package locally
python mypackage.py sdist

